package com.wutong.Filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

@WebFilter(filterName = "UserFilter",urlPatterns = {"/jsp/login.jsp"})
public class UserFilter implements Filter {
    public void destroy() {



    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {

        System.out.println("这TM拦截下来也没啥用");


        chain.doFilter(req, resp);
        System.out.println("啥都没处理就送出去");
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
