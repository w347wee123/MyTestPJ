package com.wutong.Services;

import com.wutong.Bean.Order;
import com.wutong.Bean.PageBean;
import com.wutong.Bean.User;

import java.sql.SQLException;

public interface OrderServices {
    void add(Order order);

    PageBean<Order> searchAllByUidForPage(PageBean<Order> pageBean, User user);





}
