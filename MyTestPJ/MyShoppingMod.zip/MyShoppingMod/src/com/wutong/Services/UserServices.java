package com.wutong.Services;

import com.wutong.Bean.User;

public interface UserServices {

    User login(User u);

      void regedit(User u);

     String regeditForName(String userName);


}
