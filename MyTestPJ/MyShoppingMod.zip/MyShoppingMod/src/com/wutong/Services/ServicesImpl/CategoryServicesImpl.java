package com.wutong.Services.ServicesImpl;

import com.wutong.Bean.Category;
import com.wutong.Dao.CategoryDao;
import com.wutong.Dao.DaoImpl.CategoryDaoImpl;
import com.wutong.Services.CategoryServices;

import java.util.List;

public class CategoryServicesImpl implements CategoryServices {
    private CategoryDao dao = new CategoryDaoImpl();

    @Override
    public List<Category> getAll() {
        return dao.queryAll();
    }
}
