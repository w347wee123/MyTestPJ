package com.wutong.Services.ServicesImpl;

import com.wutong.Bean.PageBean;
import com.wutong.Bean.Product;
import com.wutong.Dao.DaoImpl.ProductDaoImpl;
import com.wutong.Dao.ProductDao;
import com.wutong.Services.ProductServices;
import java.util.List;

public class ProductServicesImpl implements ProductServices{
    ProductDao pd = new ProductDaoImpl();
    @Override
    public List<Product> searchNew() {

        return pd.queryAll();
    }

    @Override
    public PageBean searchAllByCid(PageBean pageBean, String cid) {

        int pageSize = 12;
        pageBean.setPageSize(pageSize);

        int begin = (pageBean.getCurrPage()-1)*pageSize;
        pageBean.setBegin(begin);

        int totalNum = pd.searchCount(cid);

        int totalPage = totalNum%pageSize==0?(totalNum/pageSize):(totalNum/pageSize+1);
        pageBean.setTotalPage(totalPage);
        pageBean.setTotalNum(totalNum);
        List<Product> list = pd.searchAllByCid(pageBean,cid);
        pageBean.setList(list);

        return pageBean;
    }

    @Override
    public Product searchByPid(String pid) {
        return pd.searchByPid(pid);
    }


}
