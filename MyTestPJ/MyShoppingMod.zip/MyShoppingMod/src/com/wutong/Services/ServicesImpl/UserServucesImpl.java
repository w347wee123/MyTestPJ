package com.wutong.Services.ServicesImpl;

import com.wutong.Bean.User;
import com.wutong.Dao.UserDao;
import com.wutong.Dao.DaoImpl.UserDaoImpl;
import com.wutong.Services.UserServices;

public class UserServucesImpl implements UserServices{

	private UserDao dao = new UserDaoImpl();

    @Override
    public User login(User u) {
        	User user = dao.login(u);

        return user;
    }

    @Override
    public void regedit(User u) {
dao.regedit(u);
    }

    @Override
    public String regeditForName(String userName) {
        return dao.regeditForName(userName);
    }
}
