package com.wutong.Services.ServicesImpl;

import com.wutong.Bean.Order;
import com.wutong.Bean.OrderItem;
import com.wutong.Bean.PageBean;
import com.wutong.Bean.User;
import com.wutong.Dao.DaoImpl.OrderDaoImpl;
import com.wutong.Dao.OrderDao;
import com.wutong.JDBCutils.Connections.Connections;
import com.wutong.Services.OrderServices;
import org.apache.commons.dbutils.DbUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class OrderServicesImpl implements OrderServices{
   private OrderDao od = new OrderDaoImpl();

    @Override
    public void add(Order order) {
        //因为要往两个表中加数据,为了防止其中一个表的数据出错,所以这里要加事务，加事物必须保证一个事务中的多个语句使用一个Connection对象
        Connection con=null;



        try{con  = Connections.getconnection();
            //把自动提交关闭
            con.setAutoCommit(false);

            //插入数据到订单表
            od.add(order,con);
            //插入数据到订单属性列表
            for(OrderItem i: order.getList()){
                od.addItem(i,con);
            }

            //如果上面插入操作没有异常，就会直接执行到这句提交,并关闭连接
            DbUtils.commitAndCloseQuietly(con);

        }catch(Exception e){
            e.printStackTrace();
            //回滚
            DbUtils.rollbackAndCloseQuietly(con);
        }
    }

    //分页方法

    @Override
	public PageBean<Order> searchAllByUidForPage(PageBean<Order> pageBean, User user)  {

		//1、设置一页显示多少条【基础】
		int pageSize = 2;
		pageBean.setPageSize(pageSize);
		//2、计算 起始索引【基础】
		int begin = (pageBean.getCurrPage()-1)*pageBean.getPageSize();
		pageBean.setBegin(begin);
		//3、分页查询dao【基础】
        List<Order> list=null;
        Connection con=null;

        try{con  = Connections.getconnection();
            list = od.searchAllByUidForPage(pageBean,user,con);
            pageBean.setList(list);
            //4、查总记录数【扩展】
            int total = od.searchAllByUidForCount(user,con);
            pageBean.setTotalNum(total);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
           Connections.close(con);
        }


        //5、计算总页数【扩展】
		int totalPage = ((pageBean.getTotalNum()%pageBean.getPageSize()==0)?(pageBean.getTotalNum()/pageBean.getPageSize()):(pageBean.getTotalNum()/pageBean.getPageSize()+1));
		pageBean.setTotalPage(totalPage);
		return pageBean;
	}







}
