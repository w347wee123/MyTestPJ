package com.wutong.Services;

import com.wutong.Bean.PageBean;
import com.wutong.Bean.Product;
import java.util.List;

public interface ProductServices {
    List<Product> searchNew();

	PageBean searchAllByCid(PageBean pageBean, String cid);


    Product searchByPid(String pid);


}
