package com.wutong.Services;

import com.wutong.Bean.Category;

import java.util.List;

public interface CategoryServices {


    List<Category> getAll();

}
