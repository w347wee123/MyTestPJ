package com.wutong.Bean;

import java.util.HashMap;
import java.util.Map;

public class Cart {
    	/*
	 * 一个购物车里包括多个购物项 可以采用集合来处理 数组：？ list:？ map:？ <String pid,CartItem>
	 */

	private Map<String, CartItem> map = new HashMap();



	private double total;

	public Map<String, CartItem> getMap() {
		return map;
	}

	public void setMap(Map<String, CartItem> map) {
		this.map = map;

	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public Cart() {
		super();
	}

	@Override
	public String toString() {
		return "Cart [map=" + map + ", total=" + total + "]";
	}


	public void add(CartItem c) {

		map.put(c.getProduct().getPid(), c);

		c.addCartItem(c);

		total+=c.getSubTotal();
	}

	public CartItem delete(String pid) {
		CartItem ci = map.remove(pid);
		total-=ci.getSubTotal();
		return ci;
	}

	public void clear() {
		map.clear();
		total=0.0;
	}


}
