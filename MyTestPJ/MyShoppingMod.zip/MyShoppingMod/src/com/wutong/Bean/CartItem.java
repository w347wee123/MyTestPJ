package com.wutong.Bean;

public class CartItem {
    private Product product;

	// 购物项的数量
	private int count;

	// 购物项的小计金额
	private double subTotal;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public CartItem() {
		super();
	}

	@Override
	public String toString() {
		return "CartItem [product=" + product + ", count=" + count + ", subTotal=" + subTotal + "]";
	}


	public void addCartItem(CartItem item){
		item.subTotal +=item.getCount()*item.getProduct().getShopprice();
	}


}
