package com.wutong.Bean;

import java.sql.Date;

public class Product {
private String pid;
    private String pname;
    private double marketprice;
    private double shopprice;
    private String pimage;
    private Date pdate;
    private int ishot;
    private String pdesc;
    private int pflag;
    private Category category;

    public Product() {
    }

    public Product(String pid, String pname, double marketprice, double shopprice, String pimage, Date pdate, int ishot, String pdesc, int pflag, Category category) {
        this.pid = pid;
        this.pname = pname;
        this.marketprice = marketprice;
        this.shopprice = shopprice;
        this.pimage = pimage;
        this.pdate = pdate;
        this.ishot = ishot;
        this.pdesc = pdesc;
        this.pflag = pflag;
        this.category = category;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public double getMarketprice() {
        return marketprice;
    }

    public void setMarketprice(double marketprice) {
        this.marketprice = marketprice;
    }

    public double getShopprice() {
        return shopprice;
    }

    public void setShopprice(double shopprice) {
        this.shopprice = shopprice;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }

    public Date getPdate() {
        return pdate;
    }

    public void setPdate(Date pdate) {
        this.pdate = pdate;
    }

    public int getIshot() {
        return ishot;
    }

    public void setIshot(int ishot) {
        this.ishot = ishot;
    }

    public String getPdesc() {
        return pdesc;
    }

    public void setPdesc(String pdesc) {
        this.pdesc = pdesc;
    }

    public int getPflag() {
        return pflag;
    }

    public void setPflag(int pflag) {
        this.pflag = pflag;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "ProductServices{" +
                "pid='" + pid + '\'' +
                ", pname='" + pname + '\'' +
                ", marketprice=" + marketprice +
                ", shopprice=" + shopprice +
                ", pimage='" + pimage + '\'' +
                ", pdate=" + pdate +
                ", ishot=" + ishot +
                ", pdesc='" + pdesc + '\'' +
                ", pflag=" + pflag +
                ", category=" + category +
                '}';
    }
}
