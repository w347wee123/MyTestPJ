package com.wutong.Bean;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Order {
    	private String oid;
	private Date ordertime;
	private double total;
	private int state;//订单状态  0未付款  1付款未发货  2发货未收货  3确认收货
	private String address;
	private String name;
	private String telephone;

	//外键uid要用实体对应
	private User user;

	//为JSP页面上回显方便，定义一个集合，集合专门保存订单项对象  和数据库设计一点毛线关系没有!!!
	//set list map
	private List<OrderItem> list = new ArrayList<OrderItem>();


	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Date getOrdertime() {
		return ordertime;
	}

	public void setOrdertime(Date ordertime) {
		this.ordertime = ordertime;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<OrderItem> getList() {
		return list;
	}

	public void setList(List<OrderItem> list) {
		this.list = list;
	}

	public Order() {
	}

	public Order(String oid, Date ordertime, double total, int state, User user) {
		this.oid = oid;
		this.ordertime = ordertime;
		this.total = total;
		this.state = state;
		this.user = user;
	}
}
