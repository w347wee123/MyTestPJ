package com.wutong.Bean;

public class Category {

    private String cId;
  private   String cName;
    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }



    public Category() {

    }

    public Category(String cId, String cName) {
        this.cId = cId;
        this.cName = cName;
    }

    @Override
    public String toString() {
        return "Category{" +
                "cId='" + cId + '\'' +
                ", cName='" + cName + '\'' +
                '}';
    }
}
