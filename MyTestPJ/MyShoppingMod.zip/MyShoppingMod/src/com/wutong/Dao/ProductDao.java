package com.wutong.Dao;

import com.wutong.Bean.PageBean;
import com.wutong.Bean.Product;

import java.util.List;

public interface ProductDao {
    List<Product> queryAll();

  List<Product> searchAllByCid(PageBean pageBean, String cid);

 int searchCount(String cid) ;

 Product searchByPid(String pid);
}
