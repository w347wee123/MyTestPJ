package com.wutong.Dao;

import com.wutong.Bean.User;

public interface UserDao {
//登陆方法
     public User login(User u);
//注册方法
     public void regedit(User u);
//注册时的局部查询方法
     public String regeditForName(String userName);

}
