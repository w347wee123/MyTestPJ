package com.wutong.Dao.DaoImpl;


import com.wutong.Bean.Category;
import com.wutong.Bean.PageBean;
import com.wutong.Bean.Product;
import com.wutong.Dao.ProductDao;
import com.wutong.JDBCutils.Connections.Connections;
import com.wutong.JDBCutils.RowProcessor.MyBasicRowProcessor;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class ProductDaoImpl implements ProductDao {
    private QueryRunner qr = new QueryRunner();

	@Override
	public List<Product> queryAll()  {
		Connection con= null;
		List<Product> list = null;

        try {
            con= Connections.getconnection();
            String sql="select pid,pname,market_price marketprice,shop_price shopprice,pimage,pdate,is_hot ishot,pdesc,pflag,cid from product order by pdate desc limit 9";
            list = qr.query(con, sql, new BeanListHandler<Product>(Product.class));

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            Connections.close( con);
        }

		return list;
	}

    @Override
    public List<Product> searchAllByCid(PageBean pageBean, String cid) {
     		Connection conn = null;
		List<Product> list = null;
		try {
			conn = Connections.getconnection();

			String sql="select pid,pname,market_price marketPrice,shop_price shopPrice,pimage,pdate,is_hot isHot,pdesc,pflag,cid from product where cid=? limit ?,?";
			list = qr.query(conn, sql, new BeanListHandler<Product>(Product.class),cid,pageBean.getBegin(),pageBean.getPageSize());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
            e.printStackTrace();
        } finally {
			Connections.close(conn);
		}

		return list;

    }

    @Override
    public int searchCount(String cid) {
      Connection conn = null;
		Long count =null;
		try {
			conn = Connections.getconnection();

			String sql="select count(*) from product where cid=?";
			count  = (Long)qr.query(conn, sql, new ScalarHandler(),cid);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
            e.printStackTrace();
        } finally {
			Connections.close( conn);
		}

		return count.intValue();
	}

	@Override
	public Product searchByPid(String pid) {
		Connection conn = null;
		Product product = null;
		try {
			conn = Connections.getconnection();

			String sql="select p.pid pid,p.pname pname,p.market_price marketprice,p.shop_price shopprice,p.pimage pimage,p.pdate pdate,p.is_hot ishot,p.pdesc pdesc,p.pflag pflag, p.cid cId,c.cname cName from product p ,category c where p.cid=c.cid and p.pid=?";
			Map<String, Object> map = qr.query(conn, sql, new MapHandler(new MyBasicRowProcessor()),pid);
			product = new Product();

			BeanUtils.populate(product, map);

			Category c = new Category();
			BeanUtils.populate(c, map);

			product.setCategory(c);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
Connections.close( conn);
		}

		return product;
	}

}



