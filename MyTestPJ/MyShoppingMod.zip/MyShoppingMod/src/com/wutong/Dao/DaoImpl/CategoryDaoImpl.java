package com.wutong.Dao.DaoImpl;

import com.wutong.Bean.Category;
import com.wutong.Dao.CategoryDao;
import com.wutong.JDBCutils.Connections.Connections;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {

    private QueryRunner qr = new QueryRunner();

	@Override
	public List<Category> queryAll() {
		Connection conn = null;
		List<Category> list = null;
		try {
			conn = Connections.getconnection();

			String sql="select * from category";
			list = qr.query(conn, sql, new BeanListHandler<Category>(Category.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
            e.printStackTrace();
        } finally {
			Connections.close(conn);
		}
		return list;
	}




}
