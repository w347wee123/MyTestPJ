package com.wutong.Dao.DaoImpl;

import com.wutong.Bean.*;
import com.wutong.Dao.OrderDao;

import com.wutong.JDBCutils.Connections.Connections;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class OrderDaoImpl implements OrderDao{

    private QueryRunner qr = new QueryRunner();
    @Override
    public void add(Order order, Connection con) throws SQLException {

        String sql="insert into orders values (?,?,?,?,?,?,?,?)";

          qr.update(con ,sql,order.getOid(),order.getOrdertime(),order.getTotal(),
                  order.getState(),order.getAddress(),order.getName(),order.getTelephone(),
                  order.getUser().getUid());

    }

    @Override
    public void addItem(OrderItem ci, Connection con) throws SQLException {
        String sql="insert into orderitem values (?,?,?,?,?)";

        qr.update(con, sql,ci.getItemid(),ci.getCount(),ci.getSubtotal(),
                ci.getProduct().getPid(),ci.getOrder().getOid());

    }


    //分页查询
    @Override
	public List<Order> searchAllByUidForPage(PageBean<Order> pageBean, User user, Connection con) throws SQLException {

		String sql = "select * from orders where uid=? order by ordertime desc limit ?,?";
		List<Order> olist = qr.query(con,sql,new BeanListHandler<Order>(Order.class),user.getUid(),pageBean.getBegin(),pageBean.getPageSize());
		//遍历查询
		for(Order order:olist){
			String sql_orderitem = "SELECT * FROM orderitem o,product p WHERE o.oid=? AND o.pid=p.pid";
			//查询这个订单下的订单详情 数据---- 集合    LIST<Map<STRING,Object>>
			List<Map<String, Object>> temp = qr.query(con,sql_orderitem,new MapListHandler(),order.getOid());
			//分别给 订单详情对象和商品对象进行赋值
			//遍历赋值
			for(Map<String, Object> map : temp){
				OrderItem oi = new OrderItem();
				Product product = new Product();
				//商品赋值
				try {
					BeanUtils.populate(product, map);
					//订单详情赋值
					BeanUtils.populate(oi, map);
					//把商品填充进订单详情中
					oi.setProduct(product);
					//方便JSP展示，把订单详情对象放到订单的集合中
					order.getList().add(oi);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
			}

		}
		return olist;
	}

	//总记录查询
	@Override
	public int searchAllByUidForCount(User user, Connection con) throws SQLException {

		String sql = "select count(*) from orders where uid=?";
		Long temp=(Long) qr.query(con,sql,new ScalarHandler(),user.getUid());
		return temp.intValue();
	}











}
