package com.wutong.Dao.DaoImpl;

import com.wutong.Bean.User;
import com.wutong.Dao.UserDao;
import com.wutong.JDBCutils.Connections.Connections;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import javax.xml.ws.handler.Handler;
import java.sql.Connection;

public class UserDaoImpl implements UserDao{
      private QueryRunner qr=new QueryRunner();

    @Override
    public User login(User u ) {
        Connection con=null;
        try {
            con= Connections.getconnection();
            String sql="select uid,username,password from user where username=? and password=?";
           User user= qr.query(con,sql,new BeanHandler<User>(User.class),u.getUsername(),u.getPassword());
           return user;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Connections.close(con);
        }

        return null;
    }

    @Override
    public void regedit(User u) {
        Connection con=null;
        try {
           con = Connections.getconnection();
            String sql="insert into user values(?,?,?,?,?,?,?,?,?,?,?)";
            int flag= qr.update(con ,sql,u.getUid(),u.getUsername(),u.getPassword(),u.getName(),u.getPhoto(),u.getEmail(),u.getTelephone(),u.getBirthday(),u.getSex(),u.getState(),u.getCode());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Connections.close(con);
        }


    }

    @Override
    public String regeditForName(String userName) {
        Connection con=null;
        try {
            con= Connections.getconnection();
            String sql="select username from user where username=? limit 1";
            userName=(String)qr.query(con,sql,new ScalarHandler(),userName);
           return userName;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Connections.close(con);
        }
        return null;
    }
}
