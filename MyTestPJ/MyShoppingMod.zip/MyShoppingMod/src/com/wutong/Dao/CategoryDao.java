package com.wutong.Dao;

import com.wutong.Bean.Category;

import java.util.List;

public interface CategoryDao {
    List<Category> queryAll();
}
