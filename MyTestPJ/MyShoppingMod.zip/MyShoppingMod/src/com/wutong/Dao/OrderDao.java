package com.wutong.Dao;

import com.wutong.Bean.Order;
import com.wutong.Bean.OrderItem;
import com.wutong.Bean.PageBean;
import com.wutong.Bean.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    void add(Order order, Connection con) throws SQLException;

    void addItem(OrderItem ci, Connection con) throws SQLException;

	List<Order> searchAllByUidForPage(PageBean<Order> pageBean, User user, Connection con) throws SQLException;

	int searchAllByUidForCount(User user, Connection con) throws SQLException;




}
