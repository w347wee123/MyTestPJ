package com.wutong.JDBCutils.BeanUtils;

import java.util.UUID;

public class UUutils {

public static String uuidRandom(){


    return UUID.randomUUID().toString().replace("-","");
}


}
