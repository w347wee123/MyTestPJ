package com.wutong.JDBCutils.Connections;



import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Connections {

public static void close(Connection con) {

        if(con!=null) {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

public static Connection getconnection() throws Exception{
		Properties pro = new Properties();
		pro.load(Connections.class.getClassLoader().getResourceAsStream("Connection.properties"));
		String driverClass = pro.getProperty("driverClass");
		String user = pro.getProperty("user");
		String url = pro.getProperty("url");
		String password = pro.getProperty("password");

		Class.forName(driverClass);
		Connection connection = DriverManager.getConnection(url,user, password);
		return connection;
	}






}
