package com.wutong;

import com.wutong.Dao.DaoImpl.UserDaoImpl;

public class Test {



    public static void main(String[] args) {
        UserDaoImpl udi=new UserDaoImpl();
        System.out.println(udi.regeditForName("lichuan"));


    }



}
