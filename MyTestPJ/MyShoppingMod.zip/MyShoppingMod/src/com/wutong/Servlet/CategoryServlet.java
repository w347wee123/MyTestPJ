package com.wutong.Servlet;

import com.google.gson.Gson;
import com.wutong.Bean.Category;
import com.wutong.Services.CategoryServices;
import com.wutong.Services.ServicesImpl.CategoryServicesImpl;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CategoryServlet",urlPatterns = {"/Category"})
public class CategoryServlet extends BaseServlet {
   private CategoryServices service = new CategoryServicesImpl();



	private void navigate(HttpServletRequest request,HttpServletResponse response) throws IOException{

		response.setContentType("Text/html;Charset=utf-8");

		List<Category> all = service.getAll();


		Gson gson = new Gson();

		String json = gson.toJson(all);

		response.getWriter().print(json);
	}
}
