package com.wutong.Servlet;

import com.wutong.Bean.Cart;
import com.wutong.Bean.CartItem;
import com.wutong.Bean.Product;
import com.wutong.Services.ProductServices;
import com.wutong.Services.ServicesImpl.ProductServicesImpl;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



@WebServlet(name = "CartServlet",urlPatterns = {"/Cart"})
public class CartServlet extends BaseServlet {
   private static final long serialVersionUID = 1L;

	private ProductServices service = new ProductServicesImpl();

	private String add(HttpServletRequest request,HttpServletResponse response) throws IOException {

		Cart cart =(Cart) request.getSession().getAttribute("cart");
		String pid = request.getParameter("pid");
		String count = request.getParameter("count");

		if(cart==null) {
			cart = new Cart();
		}


		CartItem cartItem = new CartItem();
		cartItem.setCount(Integer.parseInt(count));


		Product product = service.searchByPid(pid);

		cartItem.setProduct(product);


		cart.add(cartItem);


		request.getSession().setAttribute("cart", cart);



		return "/jsp/cart.jsp";

	}


	private String delete(HttpServletRequest request,HttpServletResponse response) throws IOException {

		String pid = request.getParameter("pid");

		Cart cart =(Cart) request.getSession().getAttribute("cart");


		cart.delete(pid);

		request.getSession().setAttribute("cart", cart);


		return "/jsp/cart.jsp";

	}

	private String clear(HttpServletRequest request,HttpServletResponse response)  {


		String pid = request.getParameter("pid");

		Cart cart =(Cart) request.getSession().getAttribute("cart");

		cart.clear();
		request.getSession().setAttribute("cart", cart);

		return "/jsp/cart.jsp";

	}





}
