package com.wutong.Servlet;


import com.google.gson.Gson;
import com.wutong.Bean.PageBean;
import com.wutong.Bean.Product;
import com.wutong.Services.ProductServices;
import com.wutong.Services.ServicesImpl.ProductServicesImpl;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

import java.util.List;



@WebServlet(name = "ProductServlet",urlPatterns = {"/Product"})
public class ProductServlet extends BaseServlet {
    private ProductServices services=new ProductServicesImpl();
    public String searchNew(HttpServletRequest request, HttpServletResponse response){

        List<Product> list = services.searchNew();
        Gson gson = new Gson();
        String json = gson.toJson(list);
//        request.getSession().setAttribute("list",list);

        try {
            response.getWriter().println(json);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "/jsp/index.jsp";

	}

	private String searchAllByCid(HttpServletRequest request,HttpServletResponse response) throws IOException {

		PageBean<Product> pageBean = new PageBean();

		String cidStr = request.getParameter("cid");
		String currStr = request.getParameter("currPage");

		pageBean.setCurrPage(Integer.parseInt(currStr));
		pageBean = services.searchAllByCid(pageBean,cidStr);

		request.setAttribute("pageBean", pageBean);
		return "/jsp/product_list.jsp";
	}

private String searchByPid(HttpServletRequest request,HttpServletResponse response) throws IOException {

		String pid = request.getParameter("pid");

		Product product = services.searchByPid(pid);
	HttpSession session = request.getSession();
		session.setAttribute("product", product);



		return "/jsp/product_info.jsp";
	}
}
