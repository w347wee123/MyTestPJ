package com.wutong.Servlet;


import com.wutong.Bean.*;
import com.wutong.JDBCutils.BeanUtils.UUutils;
import com.wutong.Services.OrderServices;
import com.wutong.Services.ServicesImpl.OrderServicesImpl;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;


@WebServlet(name="/Orders",urlPatterns = {"/Orders"})
public class OrderServlet extends BaseServlet {
   private OrderServices os = new OrderServicesImpl();

    //添加订单
    public String add(HttpServletRequest request, HttpServletResponse response){
        //获取用户信息
        User user =(User) request.getSession().getAttribute("user");
        if(user==null){
            return "s!"+"/jsp/login.jsp";
        }
        //获取购物车产品信息
        Cart cart =  (Cart) request.getSession().getAttribute("cart");
        //判断购物项是否有内容
        if(cart==null || cart.getMap().size()==0){
            request.setAttribute("msg", "请先去购物后，再下订单");
            return "/jsp/msg.jsp";
        }
        //保存订单
        //创建订单对象，填充所需数据
        Order order = new Order(UUutils.uuidRandom(),new Date(System.currentTimeMillis()),cart.getTotal(),0,user);

        //多个订单存在时，使用集合
        List<OrderItem> list = new ArrayList<OrderItem>();
        //创建多个订单项对象。
        for(String key:cart.getMap().keySet()){
            //通过Key，查找每一个购物车项目的属性并创建CartItem对象
            CartItem ci = cart.getMap().get(key);
            //依次将购物车每一项中的每一个属性添加当前订单属性中
            OrderItem oi = new OrderItem(UUutils.uuidRandom(),ci.getCount(),ci.getSubTotal(),ci.getProduct(),order);

            //存入集合中
            list.add(oi);
        }
        order.setList(list);
        //添加到数据库中


            os.add(order);

            request.getSession().setAttribute("order", order);


        request.getSession().removeAttribute("cart");

        return  "/jsp/order_info.jsp";
    }


    public String searchAllByUidForPage(HttpServletRequest request, HttpServletResponse response){
        Integer currPage = Integer.parseInt(request.getParameter("currPage"));
        PageBean<Order> pageBean = new PageBean<Order>();
        pageBean.setCurrPage(currPage);
        User user = (User) request.getSession().getAttribute("user");
        //防止空指针异常，加入非空判断     session半小时不操作就会过期销毁
        //就是为了保证程序的健壮性
        if(user==null){
            return "/jsp/login.jsp";
        }
        //分页查询方法调用
        pageBean=os.searchAllByUidForPage(pageBean,user);
        //3、把查询的数据放入request作用域
        request.setAttribute("pageBean", pageBean);

        //4、请求转发
        return "/jsp/order_list.jsp";
    }


///**
//	 * 获取购物车的通用方法
//	 */
//	public Cart getCart(HttpServletRequest request){
//		//1、尝试从session中获取购物车
//		Cart cart = (Cart) request.getSession().getAttribute("cart");
//		//2、判断购物车是否存在
//		if(cart==null){
//			//如果session中没有购物车，创建一个购物车
//			cart = new Cart();
//		}
//		return cart;
//	}




}








