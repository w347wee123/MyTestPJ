package com.wutong.Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@WebServlet(name = "BaseServlet",urlPatterns = {"/Base"})
public class BaseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
          response.setContentType("Text/html;Charset=utf-8");
            String methodName=request.getParameter("methodName");
        try {
            //通过反射内getDeclaredMethod可以获取固定字段的方法
            Method method = this.getClass().getDeclaredMethod(methodName,HttpServletRequest.class,HttpServletResponse.class);
            method.setAccessible(true);
            //invoke可以让获取到的方法在当前位置执行
            //参数至少填一个，指定该方法的执行对象，当方法本身是静态方法时，可以填null
           String path=(String) method.invoke(this,request,response);

            if(path!=null){
                String[] split = path.split("!");
               if(split[0].equals("s")){
                   response.sendRedirect(split[1]);
               }else{
                   request.getRequestDispatcher(split[0]).forward(request, response);
               }
           }
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }
}
