package com.wutong.Servlet;

import com.google.gson.Gson;
import com.wutong.Bean.User;
import com.wutong.JDBCutils.BeanUtils.UUutils;
import com.wutong.Services.ServicesImpl.UserServucesImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@WebServlet(name = "UserServlet", urlPatterns = {"/User"})
public class UserServlet extends BaseServlet {
    private UserServucesImpl usi = new UserServucesImpl();


    private String register(HttpServletRequest request, HttpServletResponse response) throws Exception {
        User user = new User();
        //getParameterMap可以将from表单中的信息以map方式获取。
        //populate方法可以将一个map对象，按对应String字段存到对应的对象当中
        BeanUtils.populate(user, request.getParameterMap());
        user.setUid(UUutils.uuidRandom());

        usi.regedit(user);
//        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return "s!"+request.getContextPath() + "/jsp/login.jsp";
    }





     private void regeditForName(HttpServletRequest request, HttpServletResponse response) throws Exception {

         String username = request.getParameter("username");
         String Name= usi.regeditForName(username);
         Gson gson= new Gson();
         String json = gson.toJson(Name);

         response.getWriter().print(json);

    }



    private String login(HttpServletRequest request, HttpServletResponse response) throws Exception {
        User user = new User();
        BeanUtils.populate(user, request.getParameterMap());
        User u = usi.login(user);
        if (u != null) {
            setCookies(request, response, u);
            HttpSession session = request.getSession();
            session.setAttribute("user", u);
//            response.sendRedirect(request.getContextPath() + "/jsp/index.jsp");
            return "s!"+request.getContextPath() + "/jsp/index.jsp";
        } else {

            String message="用户名或密码错误，请重新输入";
            request.setAttribute("message",message);
//            request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
            return "/jsp/login.jsp";

        }

    }

    private String loginOut(HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.getSession().removeAttribute("user");

//        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return "s!"+request.getContextPath() + "/jsp/login.jsp";

    }


    private void readCookies(HttpServletRequest request, HttpServletResponse response) {

        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("username".equals(c.getName())) {
                    String value = c.getValue();
                    System.out.println(c.getName() + "=" + value);
                }
            }
        }
    }

    private void setCookies(HttpServletRequest request, HttpServletResponse response, User user) {
        Cookie cookie = new Cookie("username", user.getUsername());
        //设置cookie生效时间，参数类型为int，计算方式为秒，可以写负数，表示永不失效
        cookie.setMaxAge(7 * 60 * 60 * 24);
        //cookie值只能重写覆盖，不能修改,一般修改之后于addCookie方法一同出现
//     cookie.setValue(user.getName());
//     response.addCookie(cookie);
        //cookie可以通过设置路径，使得浏览器访问路径下位置时才会被添加cookie,
        // 默认是当前路径
        cookie.setPath(request.getContextPath() + "/jsp/login.jsp");
        response.addCookie(cookie);
    }


}
