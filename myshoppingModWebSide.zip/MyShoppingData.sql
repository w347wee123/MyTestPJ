/*
Navicat MySQL Data Transfer

Source Server         : Localhost
Source Server Version : 50527
Source Host           : localhost:3306
Source Database       : myshopping

Target Server Type    : MYSQL
Target Server Version : 50527
File Encoding         : 65001

Date: 2018-05-07 09:12:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cid` varchar(32) NOT NULL,
  `cname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '手机数码');
INSERT INTO `category` VALUES ('2', '电脑办公');
INSERT INTO `category` VALUES ('3', '家具家居');
INSERT INTO `category` VALUES ('4', '鞋靴箱包');
INSERT INTO `category` VALUES ('5', '图书音像');
INSERT INTO `category` VALUES ('6', '母婴孕婴');
INSERT INTO `category` VALUES ('7', '汽车用品');
INSERT INTO `category` VALUES ('8', '运动户外');

-- ----------------------------
-- Table structure for orderitem
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `itemid` varchar(32) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `pid` varchar(32) DEFAULT NULL,
  `oid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`itemid`),
  KEY `fk_0001` (`pid`),
  KEY `fk_0002` (`oid`),
  KEY `fk_0003` (`itemid`,`subtotal`) USING BTREE,
  CONSTRAINT `fk_0001` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`),
  CONSTRAINT `fk_0002` FOREIGN KEY (`oid`) REFERENCES `orders` (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('016a68f3bbc4478484e1ef192b4df5f8', '1', '2599', '10', '8dd63458e18f4fa4b572227654b89136');
INSERT INTO `orderitem` VALUES ('05e7ec48a36e4bd68883f5805c9b176c', '1', '2299', '50', '529006d67b1040878b9faffef4f988f7');
INSERT INTO `orderitem` VALUES ('070a23975634469fb2c2c01083f74119', '1', '1699', '23', '1bdc7e2f07dc436794e5f289a8e2c6f4');
INSERT INTO `orderitem` VALUES ('07a96defd6464a758421e5275d16810f', '1', '6688', '32', '6a685676ba744594b2e16c9ef974f648');
INSERT INTO `orderitem` VALUES ('087747c79a8f44919009fa49cacfd328', '1', '2299', '31', '6d247d3afc914925b9a491793904a52b');
INSERT INTO `orderitem` VALUES ('0c60edbd1cc14df09a5f7a7b7998661f', '1', '5499', '38', '52105aecc3a54a3c90360c69d0a821ad');
INSERT INTO `orderitem` VALUES ('0db1aeea36ad451ca28ca9028fabcb85', '1', '2299', '31', '925acec295284a478375b01fecc7e01d');
INSERT INTO `orderitem` VALUES ('0e1e5b5825b24f1c9b43984b43f1aeeb', '1', '1699', '23', '380402c39c7d428481d00ca5223c0a15');
INSERT INTO `orderitem` VALUES ('0e9125b02c8c4a2eae138150349cdde9', '1', '6688', '32', 'f4cc90e79b31407985e5dba2d457b825');
INSERT INTO `orderitem` VALUES ('0ee9f0bcaa6146a0904d0623062553c3', '1', '2298', '11', '496a5919fcc74a32ab5a742abff19baa');
INSERT INTO `orderitem` VALUES ('10b27f00f3e84c61b3e1ab054c6b0cf9', '1', '2298', '11', '622f3c01919447d1b9e28793fe8c104f');
INSERT INTO `orderitem` VALUES ('10b9a41942314382b5f802e662388557', '1', '2298', '11', 'e36821a78aa846898f9a0d583cea3832');
INSERT INTO `orderitem` VALUES ('118b9262d72f45b59c17872a3cebd7f5', '1', '2299', '9', '62992258105e4c7aa747eb1ff2228233');
INSERT INTO `orderitem` VALUES ('11a65bacf2024715b803ac6597656037', '1', '3299', '37', '904c5b50542e42ac864b7fa2c5a2b153');
INSERT INTO `orderitem` VALUES ('126a0e71f3724ba2a57c37e5a9a4ea56', '11', '28589', '10', '8b206bacde8441dfb48ad6ee12c74719');
INSERT INTO `orderitem` VALUES ('12ed19fe73e642a798e25d98cc5feadd', '1', '2299', '50', '49a81e0dccde4b04a8017bb2fa2cd2c7');
INSERT INTO `orderitem` VALUES ('13621fb04d864ab8921094408f0f5be0', '1', '4087', '16', 'f876a3553345443ab59d2f7e8b00d2fe');
INSERT INTO `orderitem` VALUES ('1669cf0ec04f482da27a8ab296daded5', '1', '2599', '10', '01aae029139145259b7b9582e13ccde8');
INSERT INTO `orderitem` VALUES ('176bb1b9435b4d14a9570069a7a9b136', '1', '6688', '32', 'b950df1871a4415daedba07c66a0a472');
INSERT INTO `orderitem` VALUES ('193136558895452aa6ad8e94f69f643a', '1', '1999', '4', '3dc181c310df499a96b5e9991393537b');
INSERT INTO `orderitem` VALUES ('19d0db3200b54391ac907162b2d8e67b', '1', '2599', '10', 'fc7a35e6ca1144de8a6f881607cfa0dd');
INSERT INTO `orderitem` VALUES ('19e885dc85fc4c388d9545ea30ca9d6d', '1', '1999', '4', 'eca1a884bf544e0fb5f65994289423b6');
INSERT INTO `orderitem` VALUES ('1af703b0ac8e451a98b65ed5599066f2', '1', '1499', '3', 'fb6759bff7004e23aeb11e8c52eb61e4');
INSERT INTO `orderitem` VALUES ('1c174f4845cf4b0e8c04e25cf5b46f1f', '1', '1799', '12', '7fcdaa2e82b94feab6be011c171beeb1');
INSERT INTO `orderitem` VALUES ('1c22ec9cfd1648a4ae3bb43df2e010ac', '1', '1190', '8', 'bc523cb1f3fa4b988d47cea6ebecdfb1');
INSERT INTO `orderitem` VALUES ('1fa9d1ff191a4e05888aaf5b27f60cee', '1', '1190', '8', 'b37c81f28e2a420aa064be55e0f27f1c');
INSERT INTO `orderitem` VALUES ('21217642f76e4d96a5bfae6fc140efa6', '1', '4399', '36', '68a24f51ca5b4c89ae903d1053097b65');
INSERT INTO `orderitem` VALUES ('252a150018c9462cade64c66857790ba', '1', '2299', '50', 'bc523cb1f3fa4b988d47cea6ebecdfb1');
INSERT INTO `orderitem` VALUES ('253bfddf0f124cd1bb1878a558a83646', '1', '1299', '1', '4e1d7f5148ad434ab12b9ea0a1e79d6e');
INSERT INTO `orderitem` VALUES ('2567d938106143808f104e46015a901b', '1', '2699', '2', '81c464a2043d4bde93dca5d266c6caeb');
INSERT INTO `orderitem` VALUES ('273924c944554d0fa44d17f6f38f1fad', '1', '2299', '31', 'e15dbaafd94847bd92542f26c7bb12dd');
INSERT INTO `orderitem` VALUES ('31a74158e8064c8fa0b8b17d59182f8d', '1', '6688', '32', '674a67b9fd8d4325affacc4e26368ecd');
INSERT INTO `orderitem` VALUES ('31e1b52a023a4b68b99a69aa0cefc355', '1', '2299', '50', '924414f3f2ee4369b5d9ec026c4997f3');
INSERT INTO `orderitem` VALUES ('32badbff8f0c4a0fa50c3a5016e30ccf', '1', '2599', '10', '925acec295284a478375b01fecc7e01d');
INSERT INTO `orderitem` VALUES ('3b18c3ef69af49759250521affd2026a', '1', '1299', '1', '6a71942b1fdb4230b7cadb8fee4a4eaa');
INSERT INTO `orderitem` VALUES ('412083fb5aee4fe783c6c851dfd68012', '1', '2299', '31', 'c5599ce42e954b81ace73b915be9118d');
INSERT INTO `orderitem` VALUES ('4194f6d06c7743798d2247b91504566a', '1', '4199', '33', '10dd9047077e4a8c8a3de3393a62cbab');
INSERT INTO `orderitem` VALUES ('43fbd9eb79ec4a49abb212e96b5b2ea9', '1', '1999', '4', '1e000d415df044a6b63a3212ca246fd0');
INSERT INTO `orderitem` VALUES ('447db52a1e194bc0baad5fc1fcd00327', '39', '105261', '2', 'f3f844e68d37423ab73c45acd1612de8');
INSERT INTO `orderitem` VALUES ('44f2d56f9f8247438d9e024cb1bf03a2', '1', '2599', '10', '5a2d718596c84766aa0274ba9f136ccd');
INSERT INTO `orderitem` VALUES ('45e828d2f74d43b58e9016dda8ad035a', '1', '1999', '4', '2c6ec0d81cb9467f9e96a9d8e79dc75a');
INSERT INTO `orderitem` VALUES ('473b41258d5448229b6455c3af8cd95c', '1', '2699', '2', '924414f3f2ee4369b5d9ec026c4997f3');
INSERT INTO `orderitem` VALUES ('4c6df90d472f4625b52ce7654b4e40f1', '1', '5499', '38', '4e1d7f5148ad434ab12b9ea0a1e79d6e');
INSERT INTO `orderitem` VALUES ('4dd7518b03a44676be87ed60be7ee433', '1', '1799', '12', '5f7d40b6391f4d25988d163dbbbce7e5');
INSERT INTO `orderitem` VALUES ('4e5fca5750224d139c368639b7cdf7d4', '11', '44957', '16', 'fb6759bff7004e23aeb11e8c52eb61e4');
INSERT INTO `orderitem` VALUES ('4f1eb555e61b4a7197ef45a951855536', '1', '2299', '31', '3809a8ecf54d4779b9e04288ec90e9fd');
INSERT INTO `orderitem` VALUES ('5204fd3b466a4c7992d15e9fb303ee8e', '1', '2299', '31', 'b284c0a071ad4b3ab9f54b5c4b087414');
INSERT INTO `orderitem` VALUES ('567b1c3433234aa2b12825a0d92eb37a', '1', '2299', '31', 'e91f215104434252adb7b374e3eef498');
INSERT INTO `orderitem` VALUES ('5920c7526a894978975c5403f7dce858', '1', '2599', '10', '8353ccc978664a5b90990c39aa4dd030');
INSERT INTO `orderitem` VALUES ('5dcc3344295d4dc0b85028d81ce41a5f', '1', '1999', '4', 'cf8ffd92329d4e8ebafbffd9a4a8c118');
INSERT INTO `orderitem` VALUES ('5e0e48e8f8774590a7a17ce7c8afb5ab', '1', '2299', '9', 'dd6ca1bada334e58bb8d16f29adc53cd');
INSERT INTO `orderitem` VALUES ('64c512ab50b449b69ce5b4e522cae0fa', '1', '6688', '32', 'c76bd66084aa420a80f945ca59edaa4e');
INSERT INTO `orderitem` VALUES ('6546849f23e84b31b62c8af46c25e2d4', '1', '5499', '38', 'f3a17a7cb6a647829bdf8db1a4809c7c');
INSERT INTO `orderitem` VALUES ('65d8701566ce4e06a96c8260baae17e2', '1', '2599', '10', 'fbc557fe981b41ed9eb3dda582d94d7b');
INSERT INTO `orderitem` VALUES ('67979415d89b4d45b3fcd0f0cb9ea9d7', '2', '5398', '2', '49a81e0dccde4b04a8017bb2fa2cd2c7');
INSERT INTO `orderitem` VALUES ('68bf3bc3e97f4b1495d000eb41fc120c', '1', '2699', '2', '529006d67b1040878b9faffef4f988f7');
INSERT INTO `orderitem` VALUES ('68e462bbb6a54c5ebcde1725ef042767', '1', '2599', '10', 'a25ff38bbc154ab18f15a0ecdc9b7cac');
INSERT INTO `orderitem` VALUES ('6ace5c1198e2444584fc08b37a404529', '1', '4199', '33', 'e36821a78aa846898f9a0d583cea3832');
INSERT INTO `orderitem` VALUES ('70a6973c656c49b7883af230356fd945', '1', '1999', '4', '896072aa7be54c4c95d73e99a0d60964');
INSERT INTO `orderitem` VALUES ('741f9b0e21464d7d8414a04469b0009b', '1', '2699', '2', '64030cc713de4476b6ce7aba08237cbd');
INSERT INTO `orderitem` VALUES ('744c5ee4d56f49ccab0ef463c05aab5f', '1', '2599', '10', '3861b7b0c02540378f473ee9c562ded6');
INSERT INTO `orderitem` VALUES ('75516d97ad5549c996789a508eb99d08', '1', '1999', '4', '6b64f63e565747f7badac126472b7a00');
INSERT INTO `orderitem` VALUES ('7b893da340a5483da4befd7a9cbd981f', '1', '2299', '50', 'ad8be8004a8c4482bdfababd9ef07edf');
INSERT INTO `orderitem` VALUES ('7d56524b470a47c1bf8d76693afff7e8', '1', '6688', '32', '3861b7b0c02540378f473ee9c562ded6');
INSERT INTO `orderitem` VALUES ('7e0eae64e4054138901417484b316223', '1', '2299', '31', '958777aaa95b48af8a47db37e27158de');
INSERT INTO `orderitem` VALUES ('7ffa019eff08483b81b2ab93fcf7219e', '1', '2299', '31', '50322d907f724a4cb78d44816486b926');
INSERT INTO `orderitem` VALUES ('80209b9bfd2e4528942a60463119c33d', '1', '2299', '31', 'c1ee55530fb8490795bb2e0f34dbbf8a');
INSERT INTO `orderitem` VALUES ('84010d4b9b4349a8b9aa9c8a3a5a907c', '1', '2599', '10', '78da68e07d0a4ac1b59324bc67f75dc7');
INSERT INTO `orderitem` VALUES ('84594eb3ad4a454a8eef3e207662e6d3', '1', '2699', '2', '2c6ec0d81cb9467f9e96a9d8e79dc75a');
INSERT INTO `orderitem` VALUES ('859939fcda4843278824d3166c1e9d6d', '12', '49044', '16', '2d68d2756bc74c708cd5470db01beaf9');
INSERT INTO `orderitem` VALUES ('87291624e34b4c97942e60b3d9561799', '1', '10288', '39', '771db6e4bce242dd9eed3770098173ad');
INSERT INTO `orderitem` VALUES ('89f2d7bc8e804dccb3bdd78ac2dcee9e', '1', '2599', '10', 'd5d51500f766452899c2193723dbc98d');
INSERT INTO `orderitem` VALUES ('8a2173b9af7049a0894076d5416265ed', '1', '2298', '11', '639e831fb7c34de3b2ffcc3d8ced2b0b');
INSERT INTO `orderitem` VALUES ('8c8a8da4a05d4dcc970836326ae47be9', '1', '2298', '11', '1b009590577a4a569fc63f3dcd8329c0');
INSERT INTO `orderitem` VALUES ('8d381561d4ee45efbccc76967a59d48b', '1', '549', '20', '02130302814b4fd2a203e57935c2db81');
INSERT INTO `orderitem` VALUES ('93766b2b2ade4b29a518d892d57a1019', '1', '2599', '10', 'b4b3642b49c4441ab0890f6df390ee96');
INSERT INTO `orderitem` VALUES ('93e70c6a13ee49a8acb47b65718dd259', '2', '4598', '9', 'b37c81f28e2a420aa064be55e0f27f1c');
INSERT INTO `orderitem` VALUES ('96e56a2510b74b35bfa5a4715d7d4700', '1', '2699', '2', '3cc7e69d66154f6dbe24e0e7ebe20afc');
INSERT INTO `orderitem` VALUES ('98cae78e858a460db0d55b580bd9ae00', '1', '2299', '31', '1c1e74d8b24643ababa853bba5a5eae3');
INSERT INTO `orderitem` VALUES ('98d1c00ec7374c5eb6387d98173e06e7', '1', '6688', '32', '3f62d1a47c3549cc8796b2e22c9b336b');
INSERT INTO `orderitem` VALUES ('9b422e33281c48c69e410cc3801bb431', '1', '6688', '32', 'bc587d151f2b4289957ec0f3aea85d2a');
INSERT INTO `orderitem` VALUES ('a1623b5fea5e49c5b0b6d1ea4efa2070', '4', '9196', '9', '64030cc713de4476b6ce7aba08237cbd');
INSERT INTO `orderitem` VALUES ('a20d4de004d44f87ada3d870be626d1a', '1', '1699', '23', 'bc523cb1f3fa4b988d47cea6ebecdfb1');
INSERT INTO `orderitem` VALUES ('a3bd5a8db8774fddb1f4e7423f5fcc64', '1', '6688', '32', '4a69ceac776f4cf6825842d5f6e5782f');
INSERT INTO `orderitem` VALUES ('a8962a6e0ab54ecda3641dded789a885', '1', '2299', '9', '940834afa5f14d1c915e279afdb361e2');
INSERT INTO `orderitem` VALUES ('a8eeeae195204553a662270b8641a120', '1', '3299', '37', 'f3a17a7cb6a647829bdf8db1a4809c7c');
INSERT INTO `orderitem` VALUES ('ab21ca310cee4262a3df07d624af31dc', '1', '1190', '8', '64030cc713de4476b6ce7aba08237cbd');
INSERT INTO `orderitem` VALUES ('ac94a297280c442fb418a9e12fdcb803', '2', '3398', '23', '48afda54d5114e17808593f709f50e49');
INSERT INTO `orderitem` VALUES ('aca5954521514245b49c47bc4feeccd4', '2', '3398', '23', 'd0906b4e44584c64b68b7902056f3ddc');
INSERT INTO `orderitem` VALUES ('ace95e7e037f4757a587888104442f41', '1', '2299', '31', 'b2bad60c0e6c4ba58d64b57b7714c1e4');
INSERT INTO `orderitem` VALUES ('b029c38a413f4f18a3795f3584f85ed7', '1', '6688', '32', '22d9f53fe1434cfba7d4fb66c7493b3c');
INSERT INTO `orderitem` VALUES ('b1923a9b8b954c158cdc86a7480806a2', '1', '4087', '16', '73b1e1939a9442e1940ced89d4cd1a60');
INSERT INTO `orderitem` VALUES ('b4b48acdacb144f68ce753d39dd86d15', '1', '2299', '9', '1e000d415df044a6b63a3212ca246fd0');
INSERT INTO `orderitem` VALUES ('bc0709a9044949d9b7463e574f4da87d', '1', '1999', '4', '81c464a2043d4bde93dca5d266c6caeb');
INSERT INTO `orderitem` VALUES ('bc6094bf0b4f4a73898f7372931a2f21', '1', '5499', '38', '771db6e4bce242dd9eed3770098173ad');
INSERT INTO `orderitem` VALUES ('bdca69ff4a9e41bc9f699bb99ed4ff9c', '1', '2298', '11', 'f7903137de7144cca26065e1211d35bb');
INSERT INTO `orderitem` VALUES ('c26aa9d211ee435394b861e3567f91c5', '1', '2699', '2', 'bc523cb1f3fa4b988d47cea6ebecdfb1');
INSERT INTO `orderitem` VALUES ('c3bc9916c7b3470fb21f23a5147ce5f8', '1', '2299', '31', '4f8a031f387543f1ac6230dde0c92f5d');
INSERT INTO `orderitem` VALUES ('c4c3b37bd2b34270b7991bd3d9714ca8', '1', '2299', '9', 'cf8ffd92329d4e8ebafbffd9a4a8c118');
INSERT INTO `orderitem` VALUES ('c53a1efb57b84737ad06c975b72e1bc3', '1', '2299', '31', '139da0914f4f4f97941e72f99c31098f');
INSERT INTO `orderitem` VALUES ('c804568ebcda449e8d10cb27b1529cc3', '1', '6688', '32', '0f405a05b3cd426a86ac73eda21b8b08');
INSERT INTO `orderitem` VALUES ('c8a279f33d0340edb521ca6f08ac8fee', '1', '2599', '10', '73b1e1939a9442e1940ced89d4cd1a60');
INSERT INTO `orderitem` VALUES ('cdb5860762a045da86ee5cc553b8ed5a', '1', '1190', '8', '8acd678c20104572bc9ec3cb12f1bc2e');
INSERT INTO `orderitem` VALUES ('d3e37114ff2c452e8158cc2c65b55faf', '1', '2599', '10', '161a38dafbe34f458d7c52bedada5136');
INSERT INTO `orderitem` VALUES ('d4949e20bb2d47f79860b19efca8c938', '1', '2299', '31', 'e509f666115444e5b94a6d34d9990267');
INSERT INTO `orderitem` VALUES ('d4efb862ccde4a4db34708fd7b366fc8', '11', '25278', '11', 'f4cc90e79b31407985e5dba2d457b825');
INSERT INTO `orderitem` VALUES ('dc67777de83a4eddb6dae68a8e3d45a9', '1', '2299', '31', '496a5919fcc74a32ab5a742abff19baa');
INSERT INTO `orderitem` VALUES ('dd9d18248bac4d0aa6f690f4b5df7dbb', '1', '2299', '31', '70ad13c64e344bc3b0d247b4fa11fff1');
INSERT INTO `orderitem` VALUES ('e219009024784d1295d7b9fe74ebf140', '1', '1999', '4', '8973c2529dee45c3b1ec848e57616761');
INSERT INTO `orderitem` VALUES ('e449d389332f4dbcb4138db434d08b6a', '1', '1699', '23', '1a567a54fc20499a91dfc87f3e6e5eee');
INSERT INTO `orderitem` VALUES ('e642e1cf92044558811d85ea0a29eb05', '1', '2299', '31', '8b206bacde8441dfb48ad6ee12c74719');
INSERT INTO `orderitem` VALUES ('e6afb082039c4d50968c6f42ce16eff9', '1', '2299', '31', 'd4dc2ffc08b94f7083df9366e4709c47');
INSERT INTO `orderitem` VALUES ('e8b71d29bf3b4d48bfd7506142ea35f9', '1', '2699', '2', 'cf8ffd92329d4e8ebafbffd9a4a8c118');
INSERT INTO `orderitem` VALUES ('ec0b371575844f37bceafef62196444a', '1', '2599', '10', '3fd18bbb366940cda7b385b05ddc4225');
INSERT INTO `orderitem` VALUES ('ed69d932170344368ba3d6236240f49a', '1', '5499', '38', '6b491e75ae924b6d917a532e2b5798da');
INSERT INTO `orderitem` VALUES ('ee5f006a0d7f43a4935fe1493e0a26e7', '1', '2599', '10', '66ac15bbf2fb4f37bece7bd66c85f7fc');
INSERT INTO `orderitem` VALUES ('ef368e96e4474244b8ebecafebffb5d9', '1', '1190', '8', '36df27e607854d5cae59d3599108e626');
INSERT INTO `orderitem` VALUES ('efac70cb984443c1abb670280b731964', '1', '2599', '10', 'bb3ca5bde72e451bbdf593b3ab03f712');
INSERT INTO `orderitem` VALUES ('f2e3cfd1c4f74f4ab65019e3248cdd0f', '1', '2699', '2', '68a24f51ca5b4c89ae903d1053097b65');
INSERT INTO `orderitem` VALUES ('f39de2499c7240908d310d3344db51f8', '1', '2699', '2', '48afda54d5114e17808593f709f50e49');
INSERT INTO `orderitem` VALUES ('f54c454d9623433f872a07e6e1a00ff7', '1', '3299', '37', '4e1d7f5148ad434ab12b9ea0a1e79d6e');
INSERT INTO `orderitem` VALUES ('f8155b79a6ef4bb89f7c84058a4e1ccd', '1', '1699', '23', '3067ec2315e148ce82d98d58c1fd994a');
INSERT INTO `orderitem` VALUES ('ff7510d226284cf3ba054b02bd767acf', '1', '4199', '33', 'bc587d151f2b4289957ec0f3aea85d2a');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `oid` varchar(32) NOT NULL,
  `ordertime` datetime DEFAULT NULL,
  `total` double DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `uid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`oid`),
  KEY `FK_USERID` (`uid`),
  CONSTRAINT `FK_USERID` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('01aae029139145259b7b9582e13ccde8', '2017-12-12 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('02130302814b4fd2a203e57935c2db81', '2017-11-07 00:00:00', '549', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('0f24cfb9c94c46ce970a9d35d3d02fa4', '2017-03-02 10:31:14', '1699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('0f405a05b3cd426a86ac73eda21b8b08', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('10dd9047077e4a8c8a3de3393a62cbab', '2017-12-12 00:00:00', '4199', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('139da0914f4f4f97941e72f99c31098f', '2017-12-12 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('161a38dafbe34f458d7c52bedada5136', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('171a3207d45a496397078282f1f7d114', '2017-02-27 15:26:42', '1699', '0', 'dd', 'ff', 'fdd', '001');
INSERT INTO `orders` VALUES ('17a252feeed048888d3f703634da2f88', '2017-03-01 11:34:32', '2699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('1a567a54fc20499a91dfc87f3e6e5eee', '2017-03-16 10:22:16', '1699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('1b009590577a4a569fc63f3dcd8329c0', '2017-11-07 00:00:00', '2298', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('1bdc7e2f07dc436794e5f289a8e2c6f4', '2017-03-16 10:09:46', '1699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('1c1e74d8b24643ababa853bba5a5eae3', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('1e000d415df044a6b63a3212ca246fd0', '2017-03-16 10:42:33', '4298', '0', '', '', '', '001');
INSERT INTO `orders` VALUES ('22d9f53fe1434cfba7d4fb66c7493b3c', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('2c6ec0d81cb9467f9e96a9d8e79dc75a', '2017-03-16 10:57:18', '4698', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('2d68d2756bc74c708cd5470db01beaf9', '2017-03-17 17:37:27', '49044', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('3067ec2315e148ce82d98d58c1fd994a', '2017-03-16 11:14:59', '1699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('36df27e607854d5cae59d3599108e626', '2017-03-16 10:26:17', '1190', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('380402c39c7d428481d00ca5223c0a15', '2017-03-16 10:47:40', '1699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('3809a8ecf54d4779b9e04288ec90e9fd', '2017-12-12 00:00:00', '2299', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('3861b7b0c02540378f473ee9c562ded6', '2017-11-07 00:00:00', '9287', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('3cc7e69d66154f6dbe24e0e7ebe20afc', '2017-03-16 10:25:29', '2699', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('3dc181c310df499a96b5e9991393537b', '2017-03-16 10:54:43', '1999', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('3f62d1a47c3549cc8796b2e22c9b336b', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('3fd18bbb366940cda7b385b05ddc4225', '2017-12-13 00:00:00', '2599', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('48afda54d5114e17808593f709f50e49', '2017-03-14 15:18:41', '6097', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('496a5919fcc74a32ab5a742abff19baa', '2017-11-07 00:00:00', '4597', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('49a81e0dccde4b04a8017bb2fa2cd2c7', '2017-03-20 15:46:44', '7697', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('4a69ceac776f4cf6825842d5f6e5782f', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('4e1d7f5148ad434ab12b9ea0a1e79d6e', '2017-03-16 11:12:24', '10097', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('4f8a031f387543f1ac6230dde0c92f5d', '2017-12-12 00:00:00', '2299', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('50322d907f724a4cb78d44816486b926', '2017-12-12 00:00:00', '2299', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('52105aecc3a54a3c90360c69d0a821ad', '2017-03-16 11:13:37', '5499', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('529006d67b1040878b9faffef4f988f7', '2017-03-20 15:18:21', '4998', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('5a2d718596c84766aa0274ba9f136ccd', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('5f7d40b6391f4d25988d163dbbbce7e5', '2017-11-07 00:00:00', '1799', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('622f3c01919447d1b9e28793fe8c104f', '2017-03-02 10:34:05', '2298', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('62992258105e4c7aa747eb1ff2228233', '2017-03-16 15:24:05', '2299', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('639e831fb7c34de3b2ffcc3d8ced2b0b', '2017-11-07 00:00:00', '2298', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('64030cc713de4476b6ce7aba08237cbd', '2017-03-18 15:53:43', '13085', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('66ac15bbf2fb4f37bece7bd66c85f7fc', '2017-12-12 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('674a67b9fd8d4325affacc4e26368ecd', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('68a24f51ca5b4c89ae903d1053097b65', '2017-03-18 15:34:23', '7098', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('6a685676ba744594b2e16c9ef974f648', '2017-12-12 00:00:00', '6688', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('6a71942b1fdb4230b7cadb8fee4a4eaa', '2017-11-07 00:00:00', '1299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('6b491e75ae924b6d917a532e2b5798da', '2017-03-16 11:08:22', '5499', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('6b64f63e565747f7badac126472b7a00', '2017-03-16 10:52:53', '1999', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('6d247d3afc914925b9a491793904a52b', '2017-12-12 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('70ad13c64e344bc3b0d247b4fa11fff1', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('73b1e1939a9442e1940ced89d4cd1a60', '2017-11-07 00:00:00', '6686', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('771db6e4bce242dd9eed3770098173ad', '2017-03-15 10:37:47', '15787', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('78da68e07d0a4ac1b59324bc67f75dc7', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('7fcdaa2e82b94feab6be011c171beeb1', '2017-11-07 00:00:00', '1799', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('81c464a2043d4bde93dca5d266c6caeb', '2017-03-20 15:14:09', '4698', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('831f77285598418da9286538b7cc5f68', '2017-02-27 14:55:00', '1398', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('8353ccc978664a5b90990c39aa4dd030', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('896072aa7be54c4c95d73e99a0d60964', '2017-03-16 10:36:13', '1999', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('8973c2529dee45c3b1ec848e57616761', '2017-03-16 10:56:32', '1999', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('8acd678c20104572bc9ec3cb12f1bc2e', '2017-03-15 10:01:09', '1190', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('8b206bacde8441dfb48ad6ee12c74719', '2017-11-07 00:00:00', '30888', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('8dd63458e18f4fa4b572227654b89136', '2017-03-16 11:01:57', '2599', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('904c5b50542e42ac864b7fa2c5a2b153', '2017-03-01 11:43:36', '4998', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('924414f3f2ee4369b5d9ec026c4997f3', '2017-03-20 15:46:35', '4998', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('925acec295284a478375b01fecc7e01d', '2017-12-14 00:00:00', '4898', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('940834afa5f14d1c915e279afdb361e2', '2017-03-16 10:41:30', '2299', '0', 'eeee', 'eeee', '222', '001');
INSERT INTO `orders` VALUES ('958777aaa95b48af8a47db37e27158de', '2017-12-12 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('a25ff38bbc154ab18f15a0ecdc9b7cac', '2017-11-07 00:00:00', '5198', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('ad8be8004a8c4482bdfababd9ef07edf', '2017-03-16 11:07:12', '2299', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('b284c0a071ad4b3ab9f54b5c4b087414', '2017-12-12 00:00:00', '2299', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('b2bad60c0e6c4ba58d64b57b7714c1e4', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('b37c81f28e2a420aa064be55e0f27f1c', '2017-03-18 15:44:55', '5788', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('b4b3642b49c4441ab0890f6df390ee96', '2017-12-12 00:00:00', '2599', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('b950df1871a4415daedba07c66a0a472', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('bb3ca5bde72e451bbdf593b3ab03f712', '2017-11-07 00:00:00', '5198', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('bc523cb1f3fa4b988d47cea6ebecdfb1', '2017-03-18 10:17:30', '7887', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('bc587d151f2b4289957ec0f3aea85d2a', '2017-11-07 00:00:00', '10887', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('c1ee55530fb8490795bb2e0f34dbbf8a', '2017-12-12 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('c5599ce42e954b81ace73b915be9118d', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('c76bd66084aa420a80f945ca59edaa4e', '2017-11-07 00:00:00', '6688', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('cf8ffd92329d4e8ebafbffd9a4a8c118', '2017-03-16 10:43:17', '6997', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('d0906b4e44584c64b68b7902056f3ddc', '2017-03-14 16:37:13', '3398', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('d4dc2ffc08b94f7083df9366e4709c47', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('d5d51500f766452899c2193723dbc98d', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('dd6ca1bada334e58bb8d16f29adc53cd', '2017-03-14 18:00:31', '2299', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('e15dbaafd94847bd92542f26c7bb12dd', '2017-12-12 00:00:00', '2299', '0', null, null, null, '8a48032e5632454eb86ffba381da7681');
INSERT INTO `orders` VALUES ('e36821a78aa846898f9a0d583cea3832', '2017-11-07 00:00:00', '6497', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('e509f666115444e5b94a6d34d9990267', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('e91f215104434252adb7b374e3eef498', '2017-11-07 00:00:00', '2299', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('eca1a884bf544e0fb5f65994289423b6', '2017-03-17 17:23:27', '1999', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('f3a17a7cb6a647829bdf8db1a4809c7c', '2017-03-16 11:09:37', '8798', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('f3f844e68d37423ab73c45acd1612de8', '2017-03-17 21:02:06', '105261', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('f4cc90e79b31407985e5dba2d457b825', '2017-11-07 00:00:00', '31966', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('f7903137de7144cca26065e1211d35bb', '2017-11-07 00:00:00', '2298', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('f876a3553345443ab59d2f7e8b00d2fe', '2017-03-16 10:13:22', '4087', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('fb6759bff7004e23aeb11e8c52eb61e4', '2017-03-17 17:36:33', '46456', '0', null, null, null, '001');
INSERT INTO `orders` VALUES ('fbc557fe981b41ed9eb3dda582d94d7b', '2017-11-07 00:00:00', '2599', '0', null, null, null, null);
INSERT INTO `orders` VALUES ('fc7a35e6ca1144de8a6f881607cfa0dd', '2017-12-12 00:00:00', '2599', '0', null, null, null, null);

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `pid` varchar(32) NOT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `market_price` double DEFAULT NULL,
  `shop_price` double DEFAULT NULL,
  `pimage` varchar(200) DEFAULT NULL,
  `pdate` datetime DEFAULT NULL,
  `is_hot` int(11) DEFAULT NULL,
  `pdesc` varchar(255) DEFAULT NULL,
  `pflag` int(11) DEFAULT NULL,
  `cid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `sfk_0001` (`cid`),
  CONSTRAINT `sfk_0001` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', '小米 4c 标准版', '1399', '1299', 'products/1/c_0001.jpg', '2015-11-02 00:00:00', '1', '小米 4c 标准版 全网通 白色 移动联通电信4G手机 双卡双待', '0', '3');
INSERT INTO `product` VALUES ('10', '华为 Ascend Mate7', '2699', '2599', 'products/1/c_0010.jpg', '2015-11-02 00:00:00', '1', '华为 Ascend Mate7 月光银 移动4G手机 双卡双待双通6英寸高清大屏，纤薄机身，智能超八核，按压式指纹识别！!选择下方“移动老用户4G飞享合约”，无需换号，还有话费每月返还！', '0', '1');
INSERT INTO `product` VALUES ('11', 'vivo X5Pro', '2399', '2298', 'products/1/c_0014.jpg', '2015-11-02 00:00:00', '1', '移动联通双4G手机 3G运存版 极光白【购机送蓝牙耳机+蓝牙自拍杆】新升级3G运行内存•双2.5D弧面玻璃•眼球识别技术', '0', '1');
INSERT INTO `product` VALUES ('12', '努比亚（nubia）My 布拉格', '1899', '1799', 'products/1/c_0013.jpg', '2015-11-02 00:00:00', '0', '努比亚（nubia）My 布拉格 银白 移动联通4G手机 双卡双待【嗨11，下单立减100】金属机身，快速充电！布拉格相机全新体验！', '0', '1');
INSERT INTO `product` VALUES ('13', '华为 麦芒4', '2599', '2499', 'products/1/c_0012.jpg', '2015-11-02 00:00:00', '1', '华为 麦芒4 晨曦金 全网通版4G手机 双卡双待金属机身 2.5D弧面屏 指纹解锁 光学防抖', '0', '1');
INSERT INTO `product` VALUES ('14', 'vivo X5M', '1899', '1799', 'products/1/c_0011.jpg', '2015-11-02 00:00:00', '0', 'vivo X5M 移动4G手机 双卡双待 香槟金【购机送蓝牙耳机+蓝牙自拍杆】5.0英寸大屏显示•八核双卡双待•Hi-Fi移动KTV', '0', '1');
INSERT INTO `product` VALUES ('15', 'Apple iPhone 6 (A1586)', '4399', '4288', 'products/1/c_0015.jpg', '2015-11-02 00:00:00', '1', 'Apple iPhone 6 (A1586) 16GB 金色 移动联通电信4G手机长期省才是真的省！点击购机送费版，月月送话费，月月享优惠，畅享4G网络，就在联通4G！', '0', '1');
INSERT INTO `product` VALUES ('16', '华为 HUAWEI Mate S 臻享版', '4200', '4087', 'products/1/c_0016.jpg', '2015-11-03 00:00:00', '0', '华为 HUAWEI Mate S 臻享版 手机 极昼金 移动联通双4G(高配)满星评价即返30元话费啦；买就送电源+清水套+创意手机支架；优雅弧屏，mate7升级版', '0', '1');
INSERT INTO `product` VALUES ('17', '索尼(SONY) E6533 Z3+', '4099', '3999', 'products/1/c_0017.jpg', '2015-11-02 00:00:00', '0', '索尼(SONY) E6533 Z3+ 双卡双4G手机 防水防尘 涧湖绿索尼z3专业防水 2070万像素 移动联通双4G', '0', '1');
INSERT INTO `product` VALUES ('18', 'HTC One M9+', '3599', '3499', 'products/1/c_0018.jpg', '2015-11-02 00:00:00', '0', 'HTC One M9+（M9pw） 金银汇 移动联通双4G手机5.2英寸，8核CPU，指纹识别，UltraPixel超像素前置相机+2000万/200万后置双镜头相机！降价特卖，惊喜不断！', '0', '1');
INSERT INTO `product` VALUES ('19', 'HTC Desire 826d 32G 臻珠白', '1599', '1469', 'products/1/c_0020.jpg', '2015-11-02 00:00:00', '1', '后置1300万+UltraPixel超像素前置摄像头+【双】前置扬声器+5.5英寸【1080p】大屏！', '0', '1');
INSERT INTO `product` VALUES ('2', '中兴 AXON', '2899', '2699', 'products/1/c_0002.jpg', '2015-11-05 00:00:00', '1', '中兴 AXON 天机 mini 压力屏版 B2015 华尔金 移动联通电信4G 双卡双待', '0', '1');
INSERT INTO `product` VALUES ('20', '小米 红米2A 增强版 白色', '649', '549', 'products/1/c_0019.jpg', '2015-11-02 00:00:00', '0', '新增至2GB 内存+16GB容量！4G双卡双待，联芯 4 核 1.5GHz 处理器！', '0', '1');
INSERT INTO `product` VALUES ('21', '魅族 魅蓝note2 16GB 白色', '1099', '999', 'products/1/c_0021.jpg', '2015-11-02 00:00:00', '0', '现货速抢，抢完即止！5.5英寸1080P分辨率屏幕，64位八核1.3GHz处理器，1300万像素摄像头，双色温双闪光灯！', '0', '1');
INSERT INTO `product` VALUES ('22', '三星 Galaxy S5 (G9008W) 闪耀白', '2099', '1999', 'products/1/c_0022.jpg', '2015-11-02 00:00:00', '1', '5.1英寸全高清炫丽屏，2.5GHz四核处理器，1600万像素', '0', '1');
INSERT INTO `product` VALUES ('23', 'sonim XP7700 4G手机', '1799', '1699', 'products/1/c_0023.jpg', '2015-11-09 00:00:00', '1', '三防智能手机 移动/联通双4G 安全 黑黄色 双4G美国军工IP69 30天长待机 3米防水防摔 北斗', '0', '1');
INSERT INTO `product` VALUES ('24', '努比亚（nubia）Z9精英版 金色', '3988', '3888', 'products/1/c_0024.jpg', '2015-11-02 00:00:00', '1', '移动联通电信4G手机 双卡双待真正的无边框！金色尊贵版！4GB+64GB大内存！', '0', '1');
INSERT INTO `product` VALUES ('25', 'Apple iPhone 6 Plus (A1524) 16GB 金色', '5188', '4988', 'products/1/c_0025.jpg', '2015-11-02 00:00:00', '0', 'Apple iPhone 6 Plus (A1524) 16GB 金色 移动联通电信4G手机 硬货 硬实力', '0', '1');
INSERT INTO `product` VALUES ('26', 'Apple iPhone 6s (A1700) 64G 玫瑰金色', '6388', '6088', 'products/1/c_0026.jpg', '2015-11-02 00:00:00', '0', 'Apple iPhone 6 Plus (A1524) 16GB 金色 移动联通电信4G手机 硬货 硬实力', '0', '1');
INSERT INTO `product` VALUES ('27', '三星 Galaxy Note5（N9200）32G版', '5588', '5388', 'products/1/c_0027.jpg', '2015-11-02 00:00:00', '0', '旗舰机型！5.7英寸大屏，4+32G内存！不一样的SPen更优化的浮窗指令！赠无线充电板！', '0', '1');
INSERT INTO `product` VALUES ('28', '三星 Galaxy S6 Edge+（G9280）32G版 铂光金', '5999', '5888', 'products/1/c_0028.jpg', '2015-11-02 00:00:00', '0', '赠移动电源+自拍杆+三星OTG金属U盘+无线充电器+透明保护壳', '0', '1');
INSERT INTO `product` VALUES ('29', 'LG G4（H818）陶瓷白 国际版', '3018', '2978', 'products/1/c_0029.jpg', '2015-11-02 00:00:00', '0', '李敏镐代言，F1.8大光圈1600万后置摄像头，5.5英寸2K屏，3G+32G内存，LG年度旗舰机！', '0', '1');
INSERT INTO `product` VALUES ('3', '华为荣耀6', '1599', '1499', 'products/1/c_0003.jpg', '2015-11-02 00:00:00', '0', '荣耀 6 (H60-L01) 3GB内存标准版 黑色 移动4G手机', '0', '1');
INSERT INTO `product` VALUES ('30', '微软(Microsoft) Lumia 640 LTE DS (RM-1113)', '1099', '999', 'products/1/c_0030.jpg', '2015-11-02 00:00:00', '0', '微软首款双网双卡双4G手机，5.0英寸高清大屏，双网双卡双4G！', '0', '1');
INSERT INTO `product` VALUES ('31', '宏碁（acer）ATC705-N50 台式电脑', '2399', '2299', 'products/1/c_0031.jpg', '2015-11-02 00:00:00', '0', '爆款直降，满千减百，品质宏碁，特惠来袭，何必苦等11.11，早买早便宜！', '0', '2');
INSERT INTO `product` VALUES ('32', 'Apple MacBook Air MJVE2CH/A 13.3英寸', '6788', '6688', 'products/1/c_0032.jpg', '2015-11-02 00:00:00', '0', '宽屏笔记本电脑 128GB 闪存', '0', '2');
INSERT INTO `product` VALUES ('33', '联想（ThinkPad） 轻薄系列E450C(20EH0001CD)', '4399', '4199', 'products/1/c_0033.jpg', '2015-11-02 00:00:00', '0', '联想（ThinkPad） 轻薄系列E450C(20EH0001CD)14英寸笔记本电脑(i5-4210U 4G 500G 2G独显 Win8.1)', '0', '2');
INSERT INTO `product` VALUES ('34', '联想（Lenovo）小新V3000经典版', '4599', '4499', 'products/1/c_0034.jpg', '2015-11-02 00:00:00', '0', '14英寸超薄笔记本电脑（i7-5500U 4G 500G+8G SSHD 2G独显 全高清屏）黑色满1000減100，狂减！火力全开，横扫3天！', '0', '2');
INSERT INTO `product` VALUES ('35', '华硕（ASUS）经典系列R557LI', '3799', '3699', 'products/1/c_0035.jpg', '2015-11-02 00:00:00', '0', '15.6英寸笔记本电脑（i5-5200U 4G 7200转500G 2G独显 D刻 蓝牙 Win8.1 黑色）', '0', '2');
INSERT INTO `product` VALUES ('36', '华硕（ASUS）X450J', '4599', '4399', 'products/1/c_0036.jpg', '2015-11-02 00:00:00', '0', '14英寸笔记本电脑 （i5-4200H 4G 1TB GT940M 2G独显 蓝牙4.0 D刻 Win8.1 黑色）', '0', '2');
INSERT INTO `product` VALUES ('37', '戴尔（DELL）灵越 飞匣3000系列', '3399', '3299', 'products/1/c_0037.jpg', '2015-11-03 00:00:00', '0', ' Ins14C-4528B 14英寸笔记本（i5-5200U 4G 500G GT820M 2G独显 Win8）黑', '0', '2');
INSERT INTO `product` VALUES ('38', '惠普(HP)WASD 暗影精灵', '5699', '5499', 'products/1/c_0038.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏笔记本电脑(i5-6300HQ 4G 1TB+128G SSD GTX950M 4G独显 Win10)', '0', '2');
INSERT INTO `product` VALUES ('39', 'Apple 配备 Retina 显示屏的 MacBook', '11299', '10288', 'products/1/c_0039.jpg', '2015-11-02 00:00:00', '0', 'Pro MF840CH/A 13.3英寸宽屏笔记本电脑 256GB 闪存', '0', '2');
INSERT INTO `product` VALUES ('4', '联想 P1', '2199', '1999', 'products/1/c_0004.jpg', '2015-11-02 00:00:00', '0', '联想 P1 16G 伯爵金 移动联通4G手机充电5分钟，通话3小时！科技源于超越！品质源于沉淀！5000mAh大电池！高端商务佳配！', '0', '1');
INSERT INTO `product` VALUES ('40', '机械革命（MECHREVO）MR X6S-M', '6799', '6599', 'products/1/c_0040.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏本(I7-4710MQ 8G 64GSSD+1T GTX960M 2G独显 IPS屏 WIN7)黑色', '0', '2');
INSERT INTO `product` VALUES ('41', '神舟（HASEE） 战神K660D-i7D2', '5699', '5499', 'products/1/c_0041.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏本(i7-4710MQ 8G 1TB GTX960M 2G独显 1080P)黑色', '0', '2');
INSERT INTO `product` VALUES ('42', '微星（MSI）GE62 2QC-264XCN', '6199', '5999', 'products/1/c_0042.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏笔记本电脑（i5-4210H 8G 1T GTX960MG DDR5 2G 背光键盘）黑色', '0', '2');
INSERT INTO `product` VALUES ('43', '雷神（ThundeRobot）G150S', '5699', '5499', 'products/1/c_0043.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏本 ( i7-4710MQ 4G 500G GTX950M 2G独显 包无亮点全高清屏) 金', '0', '2');
INSERT INTO `product` VALUES ('44', '惠普（HP）轻薄系列 HP', '3199', '3099', 'products/1/c_0044.jpg', '2015-11-02 00:00:00', '0', '15-r239TX 15.6英寸笔记本电脑（i5-5200U 4G 500G GT820M 2G独显 win8.1）金属灰', '0', '2');
INSERT INTO `product` VALUES ('45', '未来人类（Terrans Force）T5', '10999', '9899', 'products/1/c_0045.jpg', '2015-11-02 00:00:00', '0', '15.6英寸游戏本（i7-5700HQ 16G 120G固态+1TB GTX970M 3G GDDR5独显）黑', '0', '2');
INSERT INTO `product` VALUES ('46', '戴尔（DELL）Vostro 3800-R6308 台式电脑', '3299', '3199', 'products/1/c_0046.jpg', '2015-11-02 00:00:00', '0', '（i3-4170 4G 500G DVD 三年上门服务 Win7）黑', '0', '2');
INSERT INTO `product` VALUES ('48', 'Apple iPad mini 2 ME279CH/A', '2088', '1888', 'products/1/c_0048.jpg', '2015-11-02 00:00:00', '0', '（配备 Retina 显示屏 7.9英寸 16G WLAN 机型 银色）', '0', '2');
INSERT INTO `product` VALUES ('49', '小米（MI）7.9英寸平板', '1399', '1299', 'products/1/c_0049.jpg', '2015-11-02 00:00:00', '0', 'WIFI 64GB（NVIDIA Tegra K1 2.2GHz 2G 64G 2048*1536视网膜屏 800W）白色', '0', '2');
INSERT INTO `product` VALUES ('5', '摩托罗拉 moto x（x+1）', '1799', '1699', 'products/1/c_0005.jpg', '2015-11-01 00:00:00', '0', '摩托罗拉 moto x（x+1）(XT1085) 32GB 天然竹 全网通4G手机11月11天！MOTO X震撼特惠来袭！1699元！带你玩转黑科技！天然材质，原生流畅系统！', '0', '1');
INSERT INTO `product` VALUES ('50', 'Apple iPad Air 2 MGLW2CH/A', '2399', '2299', 'products/1/c_0050.jpg', '2015-11-12 00:00:00', '0', '（9.7英寸 16G WLAN 机型 银色）', '0', '2');
INSERT INTO `product` VALUES ('6', '魅族 MX5 16GB 银黑色', '1899', '1799', 'products/1/c_0006.jpg', '2015-11-02 00:00:00', '0', '魅族 MX5 16GB 银黑色 移动联通双4G手机 双卡双待送原厂钢化膜+保护壳+耳机！5.5英寸大屏幕，3G运行内存，2070万+500万像素摄像头！长期省才是真的省！', '0', '1');
INSERT INTO `product` VALUES ('7', null, '123', '123', '23524134', '2018-03-15 10:18:43', '0', '12edqwfdc32', '0', '1');
INSERT INTO `product` VALUES ('8', 'NUU NU5', '1288', '1190', 'products/1/c_0008.jpg', '2015-11-02 00:00:00', '0', 'NUU NU5 16GB 移动联通双4G智能手机 双卡双待 晒单有礼 晨光金香港品牌 2.5D弧度前后钢化玻璃 随机附赠手机套+钢化贴膜 晒单送移动电源+蓝牙耳机', '0', '1');
INSERT INTO `product` VALUES ('9', '乐视（Letv）乐1pro（X800）', '2399', '2299', 'products/1/c_0009.jpg', '2015-11-02 00:00:00', '0', '乐视（Letv）乐1pro（X800）64GB 金色 移动联通4G手机 双卡双待乐视生态UI+5.5英寸2K屏+高通8核处理器+4GB运行内存+64GB存储+1300万摄像头！', '0', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` varchar(32) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `photo` varchar(64) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('001', 'admin', '123', '管理员', null, 'service@store.com', '123456', null, '男', '1', '');
INSERT INTO `user` VALUES ('8a48032e5632454eb86ffba381da7681', '吴桐', 'w347wee123', 'wutong', null, '4654654@qq.com', null, null, '男', '0', null);
