var langList = 
[
	{name: "en_US", charset: "UTF-8"},
	{name: "zh_CN",	charset: "UTF-8"},
	{name: "zh_TW",	charset: "UTF-8"}
];

var skinList = 
[
	{name: "default", charset: "UTF-8"}
];